package org.fpm.di.test3;

import javax.inject.Inject;

public class X {
    @Inject
    public X(Y yInst, A aInst) {
    }
}
