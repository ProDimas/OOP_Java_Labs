package org.fpm.di.test7;

public interface B extends A {
}
