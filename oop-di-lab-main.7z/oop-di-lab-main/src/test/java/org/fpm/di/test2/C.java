package org.fpm.di.test2;

public abstract class C implements B {
    public C(E eInst) {
    }
}
