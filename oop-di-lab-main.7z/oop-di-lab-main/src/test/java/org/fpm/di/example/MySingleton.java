package org.fpm.di.example;

import javax.inject.Singleton;

@Singleton
public class MySingleton {
}
