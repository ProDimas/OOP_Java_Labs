package org.fpm.di.test2;

import javax.inject.Singleton;

@Singleton
public interface B {
}
