package org.fpm.di.test3;

public abstract class A {
}
