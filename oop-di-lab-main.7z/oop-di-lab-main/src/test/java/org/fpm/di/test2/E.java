package org.fpm.di.test2;

public class E extends A {
}
