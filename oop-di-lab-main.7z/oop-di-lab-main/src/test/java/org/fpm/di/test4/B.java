package org.fpm.di.test4;

public class B {
}
