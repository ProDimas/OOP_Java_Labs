package org.fpm.di.test1;

import javax.inject.Singleton;

@Singleton
public class C {
    public C() {
    }

    public String toString() {
        return " yes C. ";
    }
}
