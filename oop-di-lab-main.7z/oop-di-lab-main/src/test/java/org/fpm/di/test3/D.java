package org.fpm.di.test3;

public class D extends B {
}
