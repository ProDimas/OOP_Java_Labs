package org.fpm.di.test4;

public class C {
}
