package org.fpm.di.test2;

public class A {
}
