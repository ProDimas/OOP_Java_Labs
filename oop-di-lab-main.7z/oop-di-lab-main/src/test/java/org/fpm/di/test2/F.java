package org.fpm.di.test2;

public abstract class F {
}
