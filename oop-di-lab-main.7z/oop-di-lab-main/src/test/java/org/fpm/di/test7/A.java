package org.fpm.di.test7;

public interface A {
}
