package org.fpm.di.test3;

public class Y {
}
