package org.fpm.di.test4;

import javax.inject.Inject;

public class A {
    @Inject
    public A(B bInst, C cInst) {
    }
}
