package org.fpm.di.test3;

public class C extends B {
}
