package org.fpm.di.test5;

public class A {
}
