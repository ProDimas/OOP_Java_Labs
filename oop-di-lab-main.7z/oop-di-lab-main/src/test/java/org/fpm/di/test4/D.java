package org.fpm.di.test4;

import javax.inject.Inject;

public class D {
    @Inject
    public D(A aInst) {
    }
}
