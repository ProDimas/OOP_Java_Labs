package org.fpm.di;

public interface Configuration {
    void configure(Binder binder);
}
