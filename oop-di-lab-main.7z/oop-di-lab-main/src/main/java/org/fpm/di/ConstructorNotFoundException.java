package org.fpm.di;

class ConstructorNotFoundException extends Exception {
    ConstructorNotFoundException(String message) {
        super(message);
    }
}
