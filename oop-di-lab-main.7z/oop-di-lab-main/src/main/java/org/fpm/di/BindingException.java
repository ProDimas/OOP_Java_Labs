package org.fpm.di;

public class BindingException extends RuntimeException {
    BindingException(String message) {
        super(message);
    }
}
