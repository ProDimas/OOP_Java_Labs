package org.integral;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaboratoryWork4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
